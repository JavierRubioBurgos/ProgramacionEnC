#pragma once
#include "BaseDeDatos.h"
#include "EditarPuerto.h"
#include "EditarBuque.h"


void EstadoBuques(){

printf("                          Estado Buques                          \n\n");
printf("Id    Nombre              Puerto               Ultima Fecha           Carga\n\n");
printf("%c     %s\t\t  %s\t\t%d/%d/%d\t      %s\n",Buque1.identificador,Buque1.nombre,Buque1.PuertoSalida,Buque1.dia,Buque1.mes,Buque1.anno,Buque1.Carga);
printf("%c     %s\t\t  %s\t\t%d/%d/%d\t      %s\n",Buque2.identificador,Buque2.nombre,Buque2.PuertoSalida,Buque2.dia,Buque2.mes,Buque2.anno,Buque2.Carga);
printf("%c     %s\t\t  %s\t\t%d/%d/%d\t      %s\n",Buque3.identificador,Buque3.nombre,Buque3.PuertoSalida,Buque3.dia,Buque3.mes,Buque3.anno,Buque3.Carga);
printf("%c     %s\t\t  %s\t\t%d/%d/%d\t      %s\n",Buque4.identificador,Buque4.nombre,Buque4.PuertoSalida,Buque4.dia,Buque4.mes,Buque4.anno,Buque4.Carga);
printf("%c     %s\t\t  %s\t\t%d/%d/%d\t      %s\n",Buque5.identificador,Buque5.nombre,Buque5.PuertoSalida,Buque5.dia,Buque5.mes,Buque5.anno,Buque5.Carga);

}



