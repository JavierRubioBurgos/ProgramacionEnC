#pragma once


void ResumenMensualBuque(){

  printf("Resumen mensual Buque:\n");
  printf("Identificador Buque? \n");
  printf("Seleccion Mes? \n");
  printf("Seleccion Anno? \n");
  printf("\n\n\n\n\n\n\n\n");


  printf("Tiempo de cargas (C): \n");
  printf("Tiempo de traslados (T#): \n");
  printf("Traslado T1: \n");
  printf("Traslado T2: \n");
  printf("Tiempo de descargas (D) \n");
  printf("Tiempo de parada: \n\n");
  printf("Mostrar otro mes (S/N)? \n");

}






